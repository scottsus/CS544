# Homework 3

All answers to questions are given in `answers.ipynb`. The amazon reviews file is not included and should be copied over locally and named `amazon_reviews_us_Office_Products_v1_00.tsv`.
